import math
import time
import logging
from customer_creation import generate_customer_info
from product_creation import generate_product_info
from order_creation import generate_order_info
from order_line_creation import generate_order_line_info
print("Starting...")

logging.basicConfig(
    filename="ecommerce_simulation.log",   # log file in same folder as script
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

def simulate_ecommerce_per_two_weeks():
    customer_total_max = 8000000000          # TOTAL CUSTOMERS THAT CAN BE CREATED.
    product_total_max = 25                   # TOTAL PRODUCTS THAT CAN BE CREATED.
    order_total_max = 100000                 # TOTAL ORDERS THAT CAN BE CREATED.
    orderline_total_max = 1000000            # TOTAL ORDERLINES THAT CAN BE CREATED.
    customer_seg = 1000                      # AMOUNT OF CUSTOMERS/BATCH
    order_seg = 100                          # AMOUNT OF ORDERS/BATCH
    orderline_seg = 250                      # AMOUNT OF ORDERLINES/BATCH

    print("Creating customers...")
    for _ in range(customer_seg):
        customer = generate_customer_info(math.log(customer_total_max) * 5, customer_total_max)
        logging.info(f"New Customer Created: {customer}")
    print("Creating products...")
    for _ in range(product_total_max):
        product = generate_product_info(product_total_max)
        logging.info(f"New Product Available: {product}")
    print("Creating orders...")
    for _ in range(order_seg):
        order = generate_order_info(order_total_max * 5, order_total_max, customer_total_max)
        logging.info(f"New Order Processed: {order}")
    print("Creating order lines...")
    for _ in range(orderline_seg): 
        orderline = generate_order_line_info(orderline_total_max * 5, orderline_total_max, order_total_max, product_total_max)
        logging.info(f"OrderLine Processed: {orderline}")

if __name__ == "__main__":
    print("Creating data...")
    simulate_ecommerce_per_two_weeks()
    print("Data processed successfully.")