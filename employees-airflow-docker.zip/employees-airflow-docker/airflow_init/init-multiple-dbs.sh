# Remember to run the command:chmod +x mysql_init/init-multiple-dbs.sh
#!/bin/bash
set -e

echo "Initializing multiple databases and users..."

until mysql -h mysql -P 3306 -u root -p"$MYSQL_ROOT_PASSWORD" -e "SELECT 1;" &> /dev/null
do
  echo "Waiting for MySQL to be ready..."
  sleep 2
done

echo "MySQL is up! Creating databases and users..."
bash -c "
mysql -h mysql -P 3306 -u root -p"$MYSQL_ROOT_PASSWORD" <<-EOSQL

CREATE DATABASE IF NOT EXISTS ${MYSQL_DATABASE} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE IF NOT EXISTS ${EMPLOYEES_DATABASE} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE IF NOT EXISTS ${API_DATABASE} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS '${MYSQL_USER}'@'%' IDENTIFIED BY '${MYSQL_PASSWORD}';
CREATE USER IF NOT EXISTS '${EMPLOYEES_USER}'@'%' IDENTIFIED BY '${EMPLOYEES_PASSWORD}';
CREATE USER IF NOT EXISTS '${API_USER}'@'%' IDENTIFIED BY '${API_PASSWORD}';

GRANT ALL PRIVILEGES ON ${MYSQL_DATABASE}.* TO '${MYSQL_USER}'@'%';
GRANT ALL PRIVILEGES ON ${EMPLOYEES_DATABASE}.* TO '${EMPLOYEES_USER}'@'%';
GRANT ALL PRIVILEGES ON ${API_DATABASE}.* TO '${API_USER}'@'%';

FLUSH PRIVILEGES;
EOSQL
"

echo "Databases and users created successfully!"