import os
import json
import pandas as pd
import sqlalchemy as db
from airflow.hooks.base_hook import BaseHook

BASE_PATH = "/opt/airflow/data/incoming"
if not os.path.exists(BASE_PATH):
    BASE_PATH = "C://Users/camar/employees-airflow-docker/data/incoming"
product_file = os.path.join(BASE_PATH, "saved_products.json")
print("'PRODUCT_FILE_PATH' created successfully.")

# __________________________EXTRACTION ZONE________________________________
#For best practice, with large datasets, divide extraction into chunks
def product_extract():
    # Automatically create directory for output csv file.
    output_dir = "/opt/airflow/data/processed/"
    if not os.path.exists(output_dir):
        output_dir = "C://Users/camar/employees-airflow-docker/data/processed/"
    os.makedirs(output_dir, exist_ok=True)

    products_csv_path = os.path.join(output_dir, "products.csv")

    if os.path.exists(products_csv_path):
        print(f"Product CSV already exists at {products_csv_path}, skipping extraction.")
        return products_csv_path
    
    # Gets the extension of the file name.
    extension = os.path.splitext(product_file)[1].lower()  
    
    if extension in [".xlsx", ".xls"]:
        sheetName = ""
        df = pd.read_excel(product_file, sheet_name = sheetName)
        df.to_csv(products_csv_path, index=False)
    elif extension == ".csv":
        df = pd.read_csv(product_file)
        df.to_csv(products_csv_path, index=False)
    elif extension == ".json":
        with open(product_file, "r") as file:
            data_info = json.load(file)
        if isinstance(data_info, dict):
            data_info = list(data_info.values())
        df = pd.DataFrame(data_info)
        df.to_csv(products_csv_path, index=False)
    else:
        raise ValueError("File is unsupported.")
    
    print("CSV path returned:", products_csv_path)
    return products_csv_path

# _________________________TRANSFORMATION ZONE_______________________________
# Change column names to be more easily readable. 
# Get rid of duplicates (keep one of each product)
# Create two separate columns one with the price value and the currency code.

def product_transform(input_file_path, output_file_name, chunksize=100):
    # Automatically create directory for output csv file.
    output_dir = "/opt/airflow/data/transformed/"

    os.makedirs(output_dir, exist_ok=True)

    # Store transformed CSV file in directory.
    output_path = os.path.join(output_dir, output_file_name + ".csv")
    
    if os.path.exists(output_path):
        os.remove(output_path)

    product_data = pd.read_csv(input_file_path, chunksize=chunksize)

    header_written = False
    for data_chunks in product_data:
        # Column names have be renamed.
        data_chunks.columns = ["product_id","product_name","description","category", "brand_name", "on_hand", "unit_price"]

        # Remove duplicates
        check_for_duplicates = ['product_id', 'product_name', 'brand_name']
        data_chunks = data_chunks.drop_duplicates(subset=check_for_duplicates, keep='last')

        # Separate columns: price and currency type.
        data_chunks[['unit_price', 'currency_type']] = data_chunks['unit_price'].str.split(" ", expand=True)
        data_chunks['unit_price'] = data_chunks['unit_price'].astype(float)


        # Lastly, we will create and append chunks to new output CSV file: product_transformation.csv
        data_chunks.to_csv(
            output_path,
            mode="a",     #append to already existing file
            index=False,
            float_format="%.2f",
            header= not header_written
        )
        header_written = True
    print(f"Extracted data written to {output_path}")
    return output_path

# ____________________________LOADING ZONE_____________________________________________
def product_load(connection_id, input_file_path, table_name, chunksize=1000):
    # Create the variables for the credentials
    conn = BaseHook.get_connection(connection_id)
    connection_link = f"mysql+pymysql://{conn.login}:{conn.password}@{conn.host}:{conn.port}/{conn.schema}"

    engine = db.create_engine(connection_link)  # Engine name

    # Get and read 'input_file_path' (CSV file)
    product_data = pd.read_csv(input_file_path, chunksize=chunksize)
    # Loads transformed CSV (input_path) in chunks into MySQL.
    for i, data_chunks in enumerate(product_data):
        if i == 0:
            exist_mode = 'replace'
        else:
            exist_mode = 'append'
        data_chunks.to_sql(table_name, con=engine, if_exists=exist_mode, index=False)
    print(f"{table_name} table was successfully loaded into the MySQL Database.")
    return table_name    

    