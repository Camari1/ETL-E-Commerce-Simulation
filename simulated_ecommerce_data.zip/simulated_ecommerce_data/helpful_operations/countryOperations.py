import os
import json
import requests
import pycountry
from dotenv import load_dotenv
from babel.numbers import get_territory_currencies
from faker.config import AVAILABLE_LOCALES

def USDConversion(to_currency, price):
    # Get API key.
    env_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), ".env")
    load_dotenv(dotenv_path=env_path)
    api_key = os.getenv("EXCHANGE_RATE_API_KEY")
    from_currency = "USD"
    
    # Use Currency Rate Converter URL (Exchange Rate API) to convert USD to approrpiate currencies.
    url = f'https://v6.exchangerate-api.com/v6/{api_key}/pair/{from_currency}/{to_currency}/{price}'
    response = requests.get(url).json()
    if response['result'] == 'success':
        return response['conversion_result']
    else:
        return None
    
def numeric_price(string_price, separator= " "):
    separate = string_price.split(separator)
    number = separate[0]
    return round(float(number), 2)

def countryCurrencyMap():
    country_currency_map = {}
    for country in pycountry.countries:
        name = country.name 
        known_name = getattr(country, "common_name", None)
        code = country.alpha_2
        currencies = get_territory_currencies(code)
        if currencies:
            country_currency_map[name] = currencies[0]
        if known_name:
            country_currency_map[known_name] = currencies[0]
    return country_currency_map

def countryPostalCodeMap():
    postal_code_map = {}
    codes = AVAILABLE_LOCALES
    for code in codes:
        separate = code.split("_")
        if len(separate) == 2:
            state = separate[1]
        else:
            state = code[:2].upper()
        
        country = pycountry.countries.get(alpha_2=state)
        if country:
            postal_code_map[country.name] = code
            if hasattr(country, "common_name"):
                postal_code_map[country.common_name] = code
    return postal_code_map

# Testing: 100 USD to JPY
"""
japanese_curr = USDConversion("JPY", 100)
print(f"100 USD is equal to {japanese_curr:.2f} JPY.")


string_price = "12.30 USD"
price = numeric_price(string_price)
print(price)

print(countryPostalCodeMap())
"""