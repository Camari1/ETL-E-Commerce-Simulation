import os
import json
from pathlib import Path
from dotenv import load_dotenv


# Returns nothing if a data file does not exist. Returns data information if it does exist.
def check_filedata_exist(file_path):
    if os.path.exists(file_path):
        try:
            with open(file_path, "r") as file:
              file_info = json.load(file)
              return file_info
        except json.JSONDecodeError:
            print(f"Error: {file_path} does not exist.")
            return None
    else:
        print(f"Path: {file_path} does not exist.")
        return None

# Returns a new dictionary to store nonexistent data, returns existing file data to store new data.
def create_data_infile(file_path):
    if os.path.exists(file_path):
        try:
            with open(file_path, "r") as file:
                file_info = json.load(file)
        except json.JSONDecodeError:
            file_info = {}
    else:
        file_info= {}
    
    return file_info

def save_info(file_path, data):
    with open(file_path, "w") as file:
        json.dump(data, file, indent=4)

def create_file_path(env_variable):
    env_path = Path(__file__).parent.parent / ".env"
    # Obtained environment variables.
    load_dotenv(dotenv_path=env_path)
    
    relative_path = os.getenv(env_variable)
    if not relative_path:
        raise ValueError(f"Environment variable {env_variable} not found")

    # BASE_DIR is the folder where your script lives
    BASE_DIR = Path(__file__).parent.parent.parent.resolve()
    # Construct absolute path
    file_path = (BASE_DIR / relative_path).resolve()

    return file_path


# Testing Functions.
"""
customer_file = "C:/Users/camar/OneDrive/Documents/employees-airflow-docker/data/incoming/saved_customers.json"
order_file = "C:/Users/camar/OneDrive/Documents/employees-airflow-docker/data/incoming/saved_orders.json"
product_file = "C:/Users/camar/OneDrive/Documents/employees-airflow-docker/data/incoming/saved_products.json"
order_line_file = "C:/Users/camar/OneDrive/Documents/employees-airflow-docker/data/incoming/saved_order_lines.json"


# Let's say I was in the 'order_creation.py' file.

I want to see if I have a file that contains customer data file so i can reference it (Foreign Key).
I also want to be able to create my own 'saved_order' files if there is no file available. I also want to
be able to utilize this file to see if I have an existing id already.

So I would need two of the helpful operations: check_filedata_exist & create_data_infile.

try:
    customer_ids = check_filedata_exist(customer_file)
    order_ids = create_data_infile(order_file)
    order_id = "L2"

    while True:
        customer_id = "5"
        if customer_id in customer_ids:
            break
        if customer_id not in customer_ids:
            print("Customer does not exist in database.")
            break

    if order_id in order_ids:
        try_number = 0
        while True:
            order_id = "D4"
            # Make customer ids strings for JSON keys.
            if try_number == 10:
                print("Could not find unique ID.") 
                break
            if order_id not in order_ids:
                break
            try_number += 1
            print("Finding unique order ID...")  
    order = {
        "OrderId": order_id,
        "Date of Order": "2013-03-02",
        "CustomerID": customer_id
    }
    order_ids[order_id] = order
    save_info(order_file, order_ids)
except:
    print("You have no customers. Cannot create orders.")
"""