import time
from faker import Faker
from helpful_operations.fileOperations import create_file_path, create_data_infile, save_info
from helpful_operations.randomizeOperations import random_id, random_price, random_category, random_product_name, random_quantity




def generate_product_info(max_amount: int):
    # Create path to store Product Info.
    product_file_path = create_file_path(env_variable="PRODUCT_FILE")
    # Create data to store info and check if there are duplicate Product IDs.
    time.sleep(0.1)
    product_ids = create_data_infile(product_file_path)
    # Create Faker.
    fake = Faker()
    # Create our randomized information.
    product_id = random_id(letters=True, strt_num=1, end_num=max_amount, letter_coun=1)

    if product_id in product_ids:
        info = product_ids.get(product_id)
        info["On-Hand Quantity"] = random_quantity(0, 200000)
        save_info(product_file_path, product_ids)
        time.sleep(0.1)
        return product_ids[product_id]
    
    product_name = random_product_name()
    product_descr = fake.catch_phrase()
    category = random_category()
    company = fake.company()
    on_hand = random_quantity(0, 200000)
    unit_price = random_price(5.00, 1000.00)

    product = {
        "ProductID": product_id,
        "Product Name": product_name,
        "Product Description": product_descr,
        "Category": category,
        "Company Brand": company,
        "On-Hand Quantity": on_hand,
        "Unit Price": unit_price
    }

    product_ids[product_id] = product
    save_info(product_file_path, product_ids)
    time.sleep(0.1)
    return product


# Testing.
"""
for _ in range(4):
    p1 = generate_product_info(20)
    print("New Product released....", p1)
"""