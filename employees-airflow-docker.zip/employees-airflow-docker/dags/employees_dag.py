from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from employees_etl_logic import extract, transform, load

chunk_size = 100             # This is the amount the tasks processes in our DAG each time it runs.

# Create our default DAG
default_args = {
    'owner': 'airflow',                     # This can be a default name for a team that is working on the DAG.
    'depends_on_past': False,
    'start_date': datetime(2025, 1, 1),     # Make sure this is a date way before the current date.
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,                           # Number of retry attempts
    'retry_delay': timedelta(minutes=5)     # Specifies how long to wait to perform retry again (5 minutes)
}

# This is our customized DAG operations.
employees_dag_args = {
    'owner': 'data_engineer_team',
    'depends_on_past': False,
    'start_date': datetime(2025, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

# We officially create our DAG that can be viewed in Airflow.
with DAG(
    dag_id="daily_employee_full_load",                                                               # Name of our dag in Airflow.
    default_args=employees_dag_args,
    description="Remove duplicates, irrelevant columns, and provide default values to our table.",
    schedule_interval="@daily",
    catchup=False,                                                                                   # This loads past data from 'start_date' to present --> True (for past record use); current date, onward ---> False(for future record use/machine learning)
) as dag:
    # We create our separate tasks within Airflow DAG.
    # Extraction Task
    def employee_extraction_task():
        return extract()
    
    extraction_operator = PythonOperator(
        task_id="extract_employee_data",
        python_callable=employee_extraction_task
    )

    # Transformation Task
    def employee_transformation_task(task_instance):
        # Pull the path of the csv file returned from "extract_employee_data"
        input_csv_path = task_instance.xcom_pull(task_ids='extract_employee_data')
        # Create output file name
        output_file_name = "employee_transformation"
        return transform(input_csv_path, output_file_name, chunksize=chunk_size)

    transformation_operator = PythonOperator(
        task_id="transform_employee_data",
        python_callable=employee_transformation_task
    )

    # Load Task
    def employee_load_task(task_instance):
        transformed_csv_path = task_instance.xcom_pull(task_ids='transform_employee_data')
        load("mysql_employees", transformed_csv_path, "employees",chunksize=chunk_size)
    
    load_operator = PythonOperator(
        task_id="load_employee_data",
        python_callable=employee_load_task
    )

    # Task dependencies for how the tasks should "FLOW": E->T->L
    extraction_operator >> transformation_operator >> load_operator