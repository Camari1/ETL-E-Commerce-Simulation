from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from ecommerce_etl.customer_etl import customer_extract, customer_transform, customer_load
from ecommerce_etl.product_etl import product_extract, product_transform, product_load
from ecommerce_etl.order_etl import order_extract, order_transform, order_load
from ecommerce_etl.orderline_etl import oline_extract, oline_transform, oline_load

chunk_size = 100

"""
# Create our default DAG
default_args = {
    'owner': 'airflow',                     # This can be a default name for a team that is working on the DAG.
    'depends_on_past': False,
    'start_date': datetime(2025, 1, 1),     # Make sure this is a date way before the current date.
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,                           # Number of retry attempts
    'retry_delay': timedelta(minutes=5)     # Specifies how long to wait to perform retry again (5 minutes)
}
"""

#________________________________Customers DAG_____________________________________
customers_dag_args = {
    'owner': 'customer_data_engineer_team',
    'depends_on_past': False,
    'start_date': datetime(2025, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    dag_id="weekly_customer_full_load",                                                               # Name of our dag in Airflow.
    default_args=customers_dag_args,
    description="Change column names and remove any duplicates in our table.",
    schedule_interval="@weekly",
    catchup=False,                                                                                   # This loads past data from 'start_date' to present --> True (for past record use); current date, onward ---> False(for future record use/machine learning)
) as customer_dag:
    # We create our separate tasks within Airflow DAG.
    # Extraction Task
    def customer_extraction_task():
        return customer_extract()
    
    customer_extraction_op = PythonOperator(
        task_id="extract_customer_data",
        python_callable=customer_extraction_task
    )

    # Transformation Task
    def customer_transformation_task(task_instance):
        # Pull the path of the csv file returned from "extract_customer_data"
        input_csv_path = task_instance.xcom_pull(task_ids='extract_customer_data')
        # Create output file name
        output_file_name = "customer_transformation"
        return customer_transform(input_csv_path, output_file_name, chunksize=chunk_size)

    customer_transformation_op = PythonOperator(
        task_id="transform_customer_data",
        python_callable=customer_transformation_task
    )

    # Load Task
    def customer_load_task(task_instance):
        transformed_csv_path = task_instance.xcom_pull(task_ids='transform_customer_data')
        customer_load("mysql_api", transformed_csv_path, "customers", chunksize=chunk_size)
    
    customer_load_op = PythonOperator(
        task_id="load_customer_data",
        python_callable=customer_load_task
    )
    # Task dependencies for how the tasks should "FLOW": E->T->L
    customer_extraction_op >> customer_transformation_op >> customer_load_op

#________________________________Products DAG_____________________________________
products_dag_args = {
    'owner': 'products_data_engineer_team',
    'depends_on_past': False,
    'start_date': datetime(2025, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    dag_id="daily_product_full_load",                                                               # Name of our dag in Airflow.
    default_args=products_dag_args,
    description="Change column names and remove any duplicates in our table.",
    schedule_interval="@daily",
    catchup=False,                                                                                   # This loads past data from 'start_date' to present --> True (for past record use); current date, onward ---> False(for future record use/machine learning)
) as product_dag:
    # We create our separate tasks within Airflow DAG.
    # Extraction Task
    def product_extraction_task():
        return product_extract()
    
    product_extraction_op = PythonOperator(
        task_id="extract_product_data",
        python_callable=product_extraction_task
    )

    # Transformation Task
    def product_transformation_task(task_instance):
        # Pull the path of the csv file returned from "extract_product_data"
        input_csv_path = task_instance.xcom_pull(task_ids='extract_product_data')
        # Create output file name
        output_file_name = "product_transformation"
        return product_transform(input_csv_path, output_file_name, chunksize=chunk_size)

    product_transformation_op = PythonOperator(
        task_id="transform_product_data",
        python_callable=product_transformation_task
    )

    # Load Task
    def product_load_task(task_instance):
        transformed_csv_path = task_instance.xcom_pull(task_ids='transform_product_data')
        product_load("mysql_api", transformed_csv_path, "products", chunksize=chunk_size)
    
    product_load_op = PythonOperator(
        task_id="load_product_data",
        python_callable=product_load_task
    )
    # Task dependencies for how the tasks should "FLOW": E->T->L
    product_extraction_op >> product_transformation_op >> product_load_op

#________________________________Orders DAG_____________________________________
orders_dag_args = {
    'owner': 'orders_data_engineer_team',
    'depends_on_past': False,
    'start_date': datetime(2025, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    dag_id="daily_orders_full_load",                                                               # Name of our dag in Airflow.
    default_args=orders_dag_args,
    description="Change column names and remove any duplicates in our table.",
    schedule_interval="@daily",
    catchup=False,                                                                                   # This loads past data from 'start_date' to present --> True (for past record use); current date, onward ---> False(for future record use/machine learning)
) as order_dag:
    # We create our separate tasks within Airflow DAG.
    # Extraction Task
    def order_extraction_task():
        return order_extract()
    
    order_extraction_op = PythonOperator(
        task_id="extract_order_data",
        python_callable=order_extraction_task
    )

    # Transformation Task
    def order_transformation_task(task_instance):
        # Pull the path of the csv file returned from "extract_order_data"
        input_csv_path = task_instance.xcom_pull(task_ids='extract_order_data')
        # Create output file name
        output_file_name = "order_transformation"
        return order_transform(input_csv_path, output_file_name, chunksize=chunk_size)

    order_transformation_op = PythonOperator(
        task_id="transform_order_data",
        python_callable=order_transformation_task
    )

    # Load Task
    def order_load_task(task_instance):
        transformed_csv_path = task_instance.xcom_pull(task_ids='transform_order_data')
        order_load("mysql_api", transformed_csv_path, "orders", chunksize=chunk_size)
    
    order_load_op = PythonOperator(
        task_id="load_order_data",
        python_callable=order_load_task
    )
    # Task dependencies for how the tasks should "FLOW": E->T->L
    order_extraction_op >> order_transformation_op >> order_load_op

#________________________________Orderline DAG_____________________________________
orderlines_dag_args = {
    'owner': 'orderline_data_engineer_team',
    'depends_on_past': False,
    'start_date': datetime(2025, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    dag_id="weekly_orderline_full_load",                                                               # Name of our dag in Airflow.
    default_args=orderlines_dag_args,
    description="Change column names, standardize monetary value, and remove any duplicates in our table.",
    schedule_interval="@weekly",
    catchup=False,                                                                                   # This loads past data from 'start_date' to present --> True (for past record use); current date, onward ---> False(for future record use/machine learning)
) as orderline_dag:
    # We create our separate tasks within Airflow DAG.
    # Extraction Task
    def oline_extraction_task():
        return oline_extract()
    
    orderline_extraction_op = PythonOperator(
        task_id="extract_orderline_data",
        python_callable=oline_extraction_task
    )

    # Transformation Task
    def oline_transformation_task(task_instance):
        # Pull the path of the csv file returned from "extract_orderline_data"
        input_csv_path = task_instance.xcom_pull(task_ids='extract_orderline_data')
        # Create output file name
        output_file_name = "orderline_transformation"
        return oline_transform(input_csv_path, output_file_name, chunksize=chunk_size)

    orderline_transformation_op = PythonOperator(
        task_id="transform_orderline_data",
        python_callable=oline_transformation_task
    )

    # Load Task
    def oline_load_task(task_instance):
        transformed_csv_path = task_instance.xcom_pull(task_ids='transform_orderline_data')
        oline_load("mysql_api", transformed_csv_path, "orderlines", chunksize=chunk_size)
    
    orderline_load_op = PythonOperator(
        task_id="load_orderline_data",
        python_callable=oline_load_task
    )
    # Task dependencies for how the tasks should "FLOW": E->T->L
    orderline_extraction_op >> orderline_transformation_op >> orderline_load_op