import time
import pandas as pd
from faker import Faker
from helpful_operations.randomizeOperations import random_id
from helpful_operations.fileOperations import create_data_infile, save_info, check_filedata_exist, create_file_path

def generate_order_info(unique_id_attempts: int, order_max_amount: int, customer_max_amount: int):
    # Create file paths.
    order_file_path = create_file_path("ORDER_FILE")             
    customer_file_path = create_file_path("CUSTOMER_FILE")       

    # Our Foreign Key.
    time.sleep(0.1)
    customer_ids = check_filedata_exist(customer_file_path)                   

    # Create data to store info and check if there are duplicate Customer IDs.
    time.sleep(0.1)
    order_ids = create_data_infile(order_file_path)
    # Check if customers exists.
    if customer_ids:
        fake = Faker()
        # Check to see if order_id is unique.
        order_id = random_id(letters=True, strt_num=1, end_num=order_max_amount, letter_coun=2)
        if order_id in order_ids:
            try_number = 0
            while True:
                order_id = random_id(letters=True, strt_num=1, end_num=order_max_amount, letter_coun=2)
                if try_number == unique_id_attempts:
                    return None
                if order_id not in order_ids:
                    break
                try_number += 1
                print("Finding unique order ID...")  
        # Keep creating customer IDs until it is one that exists within the JSON file.
        while True:
            customer_id = random_id(strt_num=1, end_num=customer_max_amount)
            if customer_id in customer_ids:
                break
        # If everything passes, create new order. Create our randomized information.
        order_date = str(pd.Timestamp.today().normalize())
        order = {
            "OrderID": order_id,
            "Order Date": order_date,
            "CustomerID": customer_id
        }
        order_ids[order_id] = order
        save_info(order_file_path, order_ids)
        time.sleep(0.1)
        return order
    
    else:
        print("There are no customers. Cannot create any orders.")
        return None
    
# Testing.
"""
o1 = generate_order_info(10, order_max_amount=3, customer_max_amount=8)
print("New Order created.....", o1)
"""
