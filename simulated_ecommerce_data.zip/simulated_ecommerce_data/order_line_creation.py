import time
from helpful_operations.randomizeOperations import random_id, random_quantity
from helpful_operations.countryOperations import countryCurrencyMap, USDConversion, numeric_price
from helpful_operations.fileOperations import create_file_path, check_filedata_exist, create_data_infile, save_info


def generate_order_line_info(unique_id_attempts: int, orderline_max_n: int, order_max_n: int, product_max_n: int):
    # Create file paths.
    order_line_file_path = create_file_path("ORDER_LINE_FILE")
    order_file_path = create_file_path("ORDER_FILE")
    product_file_path = create_file_path("PRODUCT_FILE")
    customer_file_path = create_file_path("CUSTOMER_FILE")

    # Our Foreign Keys.
    time.sleep(0.1)
    customer_ids = check_filedata_exist(customer_file_path)
    product_ids = check_filedata_exist(product_file_path)
    order_ids = check_filedata_exist(order_file_path)

    # Create data to store info and check if there are duplicate Customer IDs.
    time.sleep(0.1)
    order_line_ids = create_data_infile(order_line_file_path)

    # Check if both products & orders exist.
    if product_ids and order_ids and customer_ids:
        # Check to see if order_id is unique.
        orderLineID = random_id(letters=True, strt_num=1, end_num=orderline_max_n, letter_coun=3)
        if orderLineID in order_ids:
            try_number = 0
            while True:
                orderLineID = random_id(letters=True, strt_num=1, end_num=orderline_max_n, letter_coun=3)
                if try_number == unique_id_attempts:
                    return None
                if orderLineID not in order_ids:
                    break
                try_number += 1
                print("Finding unique order line ID...")
        # Keep creating order IDs until it is one that exists within the JSON file.
        while True:
            order_id = random_id(letters=True, strt_num=1, end_num=order_max_n, letter_coun=2)
            if order_id in order_ids:
                break
        
        while True:
            product_id = random_id(letters=True, strt_num=1, end_num=product_max_n, letter_coun=1)
            if product_id in product_ids:
                break
        
        # Convert our USD product price to appropriate currency price.
        currency_map = countryCurrencyMap()
        # Get ProductID ---> Then, get product info.
        product_info = product_ids.get(product_id)
        # Once you have product info, get value for 'Unit Price'
        string_price = product_info.get("Unit Price")
        # Once you have unit price, separate and make price numeric value.
        usa_price = numeric_price(string_price)

        # Look for the CustomerID within the OrderID.
        customer_id = (order_ids.get(order_id)).get("CustomerID")
        # When we have the CustomerID in the OrderId, we need to look up customer info ('Country').
        country_of_customer = (customer_ids.get(customer_id)).get("Country")
        # Convert USD amount to customer country currency amount.
        currency_type = currency_map.get(country_of_customer)
        converted_currency = USDConversion(currency_type, usa_price)

        # Take conversion amount
        if converted_currency:
            quoted_price = f"{converted_currency:.2f} " + currency_type
        else:
            print("Currency not supported.")
            quoted_price = converted_currency

        # If everything passes, create new order. Create our randomized information.
        quantity = random_quantity(strt_num=1, end_num=10)    
        order_line = {
            "LineID":orderLineID,
            "OrderID": order_id,
            "ProductID": product_id,
            "Quantity": quantity,
            "Quoted Price": quoted_price
        }
        order_line_ids[orderLineID] = order_line
        save_info(order_line_file_path, order_line_ids)
        time.sleep(0.1)
        return order_line
    
    else:
        if product_ids and not order_ids and not customer_ids:
            print("Products exists, but there are no orders or customers to place orders.")
            return None
        elif product_ids and order_ids and not customer_ids:
            print("Products and orders exists, but there are no customers.")
            return None
        elif customer_ids and order_ids and not product_ids:
            print("Customers and orders exists, but there are no products to purchase.")
            return None
        print("There are no products available.")
        return None

# Testing.
"""
ol = generate_order_line_info(10, orderline_max_n=500000000,order_max_n=3,product_max_n=20)
print("New Order line created...", ol)
"""
