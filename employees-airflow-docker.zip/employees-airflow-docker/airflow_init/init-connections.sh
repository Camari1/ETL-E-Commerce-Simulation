
#!/bin/bash

sleep 10

echo ">>> Setting up Airflow connections..."

bash -c "
airflow connections add 'mysql_employees' \
    --conn-type 'mysql' \
    --conn-host 'mysql' \
    --conn-login "$EMPLOYEES_USER" \
    --conn-password "$(python3 -c "import urllib.parse, os; print(urllib.parse.quote(os.environ['EMPLOYEES_PASSWORD']))")" \
    --conn-schema "$EMPLOYEES_DATABASE" \
    --conn-port 3306

airflow connections add 'mysql_api' \
    --conn-type 'mysql' \
    --conn-host 'mysql' \
    --conn-login "$API_USER" \
    --conn-password "$(python3 -c "import urllib.parse, os; print(urllib.parse.quote(os.environ['API_PASSWORD']))")" \
    --conn-schema "${API_DATABASE}" \
    --conn-port 3306
"
# So on..... continue to do this for as many projects that you have.

echo ">>> Done creating connections!"
exit 0