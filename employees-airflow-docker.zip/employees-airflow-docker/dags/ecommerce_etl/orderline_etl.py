import os
import json
import requests
import pandas as pd
import sqlalchemy as db
from dotenv import load_dotenv
from airflow.hooks.base_hook import BaseHook

def get_exchange_rate():
    # Get API key.
    env_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), ".env")
    load_dotenv(dotenv_path=env_path)
    api_key = os.getenv("EXCHANGE_RATE_API_KEY")
    to_currency = "USD"
    
    # Use Currency Rate Converter URL (Exchange Rate API) to convert USD to approrpiate currencies.
    url = f'https://v6.exchangerate-api.com/v6/{api_key}/latest/{to_currency}'
    response = requests.get(url).json()
    if response['result'] == 'success':
        return response['conversion_rates']
    else:
        return None
    
def convert_prices(df, price_col="original_price", currency_col="currency_type"):
    rates = get_exchange_rate()
    def convert_rate(row):
        from_currency = row[currency_col]
        price = float(row[price_col])

        if from_currency not in rates:
            return price
        return price / rates[from_currency]
    df["usa_price"] = df.apply(convert_rate, axis=1)
    return df

BASE_PATH = "/opt/airflow/data/incoming"
if not os.path.exists(BASE_PATH):
    BASE_PATH = "C://Users/camar/employees-airflow-docker/data/incoming"
orderline_file = os.path.join(BASE_PATH, 'saved_order_lines.json')
print("'ORDERLINE_FILE_PATH' created successfully.")

# __________________________EXTRACTION ZONE________________________________
#For best practice, with large datasets, divide extraction into chunks
def oline_extract():
    # Automatically create directory for output csv file.
    output_dir = "/opt/airflow/data/processed/"
    if not os.path.exists(output_dir):
        output_dir = "C://Users/camar/employees-airflow-docker/data/processed/"
    os.makedirs(output_dir, exist_ok=True)

    orderlines_csv_path = os.path.join(output_dir, "orderlines.csv")

    if os.path.exists(orderlines_csv_path):
        print(f"Order Line CSV already exists at {orderlines_csv_path}, skipping extraction.")
        return orderlines_csv_path
    
    # Gets the extension of the file name.
    extension = os.path.splitext(orderline_file)[1].lower()  
    
    if extension in [".xlsx", ".xls"]:
        sheetName = ""
        df = pd.read_excel(orderline_file, sheet_name = sheetName)
        df.to_csv(orderlines_csv_path, index=False)
    elif extension == ".csv":
        df = pd.read_csv(orderline_file)
        df.to_csv(orderlines_csv_path, index=False)
    elif extension == ".json":
        with open(orderline_file, "r") as file:
            data_info = json.load(file)
        if isinstance(data_info, dict):
            data_info = list(data_info.values())
        df = pd.DataFrame(data_info)
        df.to_csv(orderlines_csv_path, index=False)
    else:
        raise ValueError("File is unsupported.")
    
    print("CSV path returned:", orderlines_csv_path)
    return orderlines_csv_path

# _________________________TRANSFORMATION ZONE_______________________________
# Change column names to be more easily readable. 
# Get rid of duplicates (keep one of each orderline)
# Standardize monetary prices. Convert prices to floats.
# Get rid of non-accepted currency types.

def oline_transform(input_file_path, output_file_name, chunksize=100):
    # Automatically create directory for output csv file.
    output_dir = "/opt/airflow/data/transformed/"

    os.makedirs(output_dir, exist_ok=True)

    # Store transformed CSV file in directory.
    output_path = os.path.join(output_dir, output_file_name + ".csv")
    
    if os.path.exists(output_path):
        os.remove(output_path)
    
    orderline_data = pd.read_csv(input_file_path, chunksize=chunksize)
    
    # Remove any duplicates.
    header_written = False
    for data_chunks in orderline_data:
        # Column names have be renamed.
        data_chunks.columns = ["orderline_id","order_id","product_id","quantity", "original_quoted_price"]

        # Get rid of duplicates.
        check_for_duplicates = ['orderline_id', 'order_id', 'product_id']
        data_chunks = data_chunks.drop_duplicates(subset=check_for_duplicates, keep='last')

        data_chunks.dropna(subset=["original_quoted_price"], inplace=True)
        
        # Standardize monetary value. Convert non-USD to USD.
        # We create two separate columns 'original_price' & 'currency_type'. 
        # We split them up by the " " separator in our "original_quoted_price" column.
        # We then take the price in our 'original_price' column and make it a float.

        data_chunks[['original_price', 'currency_type']] = data_chunks['original_quoted_price'].str.split(" ", expand=True)
        data_chunks['original_price'] = data_chunks['original_price'].astype(float)

        data_chunks = convert_prices(data_chunks)

        # Lastly, we will create and append chunks to new output CSV file: customer_transformation.csv
        data_chunks.to_csv(
            output_path,
            mode="a",     #append to already existing file
            index=False,
            float_format="%.2f",
            header= not header_written
        )
        header_written = True
    print(f"Extracted data written to {output_path}")
    return output_path

# ____________________________LOADING ZONE_____________________________________________
def oline_load(connection_id, input_file_path, table_name, chunksize=1000):
    # Create the variables for the credentials
    conn = BaseHook.get_connection(connection_id)
    connection_link = f"mysql+pymysql://{conn.login}:{conn.password}@{conn.host}:{conn.port}/{conn.schema}"

    engine = db.create_engine(connection_link)  # Engine name

    # Get and read 'input_file_path' (CSV file)
    orderline_data = pd.read_csv(input_file_path, chunksize=chunksize)
    # Loads transformed CSV (input_path) in chunks into MySQL.
    for i, data_chunks in enumerate(orderline_data):
        if i == 0:
            exist_mode = 'replace'
        else:
            exist_mode = 'append'
        data_chunks.to_sql(table_name, con=engine, if_exists=exist_mode, index=False)
    print(f"{table_name} table was successfully loaded into the MySQL Database.")
    return table_name    