import random
import string


def random_id(nums=True, letters=False, strt_num=1, end_num=100, letter_coun=1):
    random_id = ""
    # Returns only numeric random id.
    if nums and not letters:
        random_id += str(random.randint(strt_num, end_num))
        return random_id
    # Returns only alphabetic random id.
    elif letters and not nums:
        for _ in range(letter_coun):
            random_id += random.choice(string.ascii_uppercase)
        return random_id
    # Returns a combination of numeric and alphabetic random id.
    elif letters and nums:
        for _ in range(letter_coun):
            random_id += random.choice(string.ascii_uppercase)
        random_id += str(random.randint(strt_num, end_num))
        return random_id
    # Returns nothing if neither.
    else:
        return None

def random_product_name():
    adjectives = [ 
        'Amazing', 'Cool', 'Fragrance-Free', 'Enticing', 'Odorless', 'Fruity',
        'Clean', 'Smooth', 'Perfect', 'Silky', 'Tasty', 'Fast', 'Beautiful', 
        'Unbreakable', 'Cozy', 'Comfortable', 'Pretty', 'Special', 'Designer',
        'Water-Resistant', 'Luxurious', 'Bright', 'Large'
    ]
    nouns = [
        'Jeans', 'Shirt', 'Makeup', 'Moisturizer', 'Phone', 
        'Chair', 'Couch', 'TV', 'Airpods', 'Lamp', 'Shoes', 
        'Paint', 'Food', 'Apple Product', 'Cereal', 'Beef', 'Bedsheets',
        'Mug', 'Phone Charger', 'Pet Bed', 'Pet Toy', 'Pet Litter',
        'Pet Shampoo', 'Laptop', 'Game Console', 'Telescope' 
    ]
    return f"{random.choice(adjectives)} {random.choice(nouns)}"

def random_category():
    category = [
        'Clothing', 'Electronics', 'Home Decor', 'Home Appliances', 'Kitchen Items', 
        'Furniture', 'Pet Care', 'Beauty', 'Entertainment', 'Toys and Hobbies', 'DIY',
        'Fashion & Apparel' 
    ]
    return random.choice(category)

def random_quantity(strt_num=1, end_num=10):
    return random.randint(strt_num, end_num)

def random_price(strt_price=1.00, end_price=2.00):
    price = round(random.uniform(strt_price, end_price), 2)
    price_as_string = f"{price:.2f} USD"
    return price_as_string

# Testing Functions.
"""
cus_id = random_id(nums=True, strt_num=3, end_num=8)
print("CustomerID:", cus_id)

prod_id = random_id(nums=True, letters=True, strt_num=1, end_num=20, letter_coun=2)
print("ProductID:", prod_id)

order_id = random_id(nums=True, letters=True, strt_num=1, end_num=3, letter_coun=1)
print("OrderID:", order_id)

order_line_id = random_id(nums=True, letters=True, strt_num=1, end_num=500000000, letter_coun=3)
print("LineID:", order_line_id)

product = random_product_name()
print(product)

price = random_price(5.00, 1000.00)
print(price)
"""