import os
from dotenv import load_dotenv
import pandas as pd
import sqlalchemy as db
from airflow.hooks.base_hook import BaseHook

file_path = "/opt/airflow/employee_data/H+ Sport Employees.xlsx"  #File directory
print("'FILE_PATH' created successfully.")

# __________________________EXTRACTION ZONE________________________________
#For best practice, with large datasets, divide extraction into chunks
def extract():
    # Automatically create directory for output csv file.
    output_dir = "/opt/airflow/employee_data/converted_to_csv/"
    os.makedirs(output_dir, exist_ok=True)

    # Store CSV file in directory.
    csv_path = os.path.join(output_dir, "employees.csv")

    # Check to see if csv file already exists.
    if os.path.exists(csv_path):
        print(f"CSV already exists at {csv_path}, skipping extraction.")
        return csv_path
    
    # Gets the extension of the file name.
    extension = os.path.splitext(file_path)[1].lower()   

    # Convert Excel, JSON files into CSV files.
    if extension in [".xls",".xlsx"]:
        sheetName = "Employees-Table"
        df = pd.read_excel(file_path, sheet_name=sheetName)
        df.to_csv(csv_path, index=False)
    # Keep CSV file.
    elif extension == ".csv":
        df = pd.read_csv(file_path)
        df.to_csv(csv_path, index=False)
    # Convert JSON files into CSV files.
    elif extension == ".json":
        df = pd.read_json(file_path)
        df.to_csv(csv_path, index=False)
    # Error if it is not a supported file type.
    else:
        raise ValueError("File is unsupported.")
    
    print("CSV path returned:", csv_path)
    return csv_path

# _________________________TRANSFORMATION ZONE_______________________________
# Remove irrelevant columns "New Salary", "Tax Rate", and "2.91%" columns.
# Create default values for missing values.
# Get rid of duplicates (keep one of each employee)

def transform(input_file_path, output_file_name, chunksize=1000):
    # Automatically create directory for output csv file.
    output_dir = "/opt/airflow/employee_data/output/"
    os.makedirs(output_dir, exist_ok=True)

    # Store transformed CSV file in directory.
    output_path = os.path.join(output_dir, output_file_name + ".csv")

    if os.path.exists(output_path):
        os.remove(output_path)
    
    exclude_columns = ['New Salary', 'Tax Rate', '2.91%']
    header_written = False  # Write this the first time so header is added (True), so each time a new chunk is appended, the line where this is located, will not create the same header (False).
    
    # Convert CSV file to DataFrame.
    employee_data = pd.read_csv(input_file_path, chunksize=chunksize)
    # Go through each chunks in the csv file.
    for data_chunks in employee_data:
        # Check and Drop irrelevant columns
        data_chunks = data_chunks.drop(columns=[col for col in exclude_columns if col in data_chunks.columns], errors="ignore")

        # Replace null values with default ones.
        data_chunks = data_chunks.fillna({
            'Employee Name': "Unknown",
            'Building': "Unknown",
            'Department': "Unknown",
            'Status': "Unknown",
            'Hire Date': pd.Timestamp.today().normalize(),
            'Month': "Unknown",
            'Years': 0,
            'Benefits': "No Benefit",
            'Salary': 0,
            'Job Rating': 0
        })

        # Remove duplicates
        check_for_duplicates = ['Employee Name', 'Building', 'Department', 'Hire Date', 'Years']
        data_chunks = data_chunks.drop_duplicates(subset=check_for_duplicates, keep='first')

        # Lastly, we will create and append chunks to new output CSV file: employee_transformation.csv
        data_chunks.to_csv(
            output_path,
            mode="a",     #append to already existing file
            index=False,
            header= not header_written
        )
        header_written = True
        
    print(f"Extracted data written to {output_path}")
    return output_path
    

# ____________________________LOADING ZONE_____________________________________________

def load(connection_id, input_file_path, table_name, chunksize=1000):
    # Create the variables for the credentials
    conn = BaseHook.get_connection(connection_id)
    connection_link = f"mysql+pymysql://{conn.login}:{conn.password}@{conn.host}:{conn.port}/{conn.schema}"

    engine = db.create_engine(connection_link)  # Engine name

    # Get and read 'input_file_path' (CSV file)
    employee_data = pd.read_csv(input_file_path, chunksize=chunksize)
    # Loads transformed CSV (input_path) in chunks into MySQL.
    for i, data_chunks in enumerate(employee_data):
        if i == 0:
            exist_mode = 'replace'
        else:
            exist_mode = 'append'
        data_chunks.to_sql(table_name, con=engine, if_exists=exist_mode, index=False)
    print(f"{table_name} table was successfully loaded into the MySQL Database.")
    return table_name