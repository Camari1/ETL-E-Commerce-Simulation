import time
from faker import Faker
from helpful_operations.randomizeOperations import random_id
from helpful_operations.countryOperations import countryPostalCodeMap
from helpful_operations.fileOperations import create_data_infile, save_info, create_file_path


# Obtain Postal Mapping Chart.
def get_postal_code(country):
    postal_codes = countryPostalCodeMap()
    locale = postal_codes.get(country, 'en_US')
    fake = Faker(locale)
    try:
        return fake.postalcode()
    except:
        fake = Faker()
        return fake.zipcode()
    
def generate_customer_info(unique_id_attempts: int, max_amount: int):
    # Create path to store Customer Info.
    customer_file_path = create_file_path(env_variable="CUSTOMER_FILE") 
    # Create data to store info and check if there are duplicate Customer IDs.
    time.sleep(0.1)
    customer_ids = create_data_infile(customer_file_path)
    # Create Faker.
    fake = Faker()

    # Check to see if there are duplicate emails. If emails are the same -> Update address info.
    email = fake.email()
    for customer_id, info in customer_ids.items():
        if info['Email'] == email:
            new_country = fake.country()
            customer_ids[customer_id]['Street Address'] = fake.street_address()
            customer_ids[customer_id]['City'] = fake.city()
            customer_ids[customer_id]['Country'] = new_country
            customer_ids[customer_id]['Postal Code'] = get_postal_code(new_country)
            save_info(customer_file_path, customer_ids)
            return customer_ids[customer_id]
    
    # Check to see if Customer ID exist.
    try_number = 0
    while True:
        # Create Customer IDs.            
        customer_id = random_id(strt_num=1, end_num=max_amount)     # strt=1, end=8000000000
        if try_number == unique_id_attempts:
            print("Could not create new customers.")
            return None
        if customer_id not in customer_ids:
            break
        try_number += 1
        print("Finding new customer to add...")

    # Create our randomized information.
    name = fake.name()
    street_address = fake.street_address()
    city = fake.city()
    country = fake.country()
    postcode = get_postal_code(country)
    dob = str(fake.date_of_birth(minimum_age=16, maximum_age=98))
    
    customer = {
        "CustomerID": customer_id,
        "Name": name,
        "Email": email,
        "Street Address": street_address,
        "City": city,
        "Country": country,
        "Postal Code": postcode,
        "DOB": dob
    }
    customer_ids[customer_id] = customer
    save_info(customer_file_path, customer_ids)
    time.sleep(0.1)
    return customer

# Testing.
"""
for _ in range(2):
    c1 = generate_customer_info(10, max_amount=8)
    print("New Customer created....", c1)
"""